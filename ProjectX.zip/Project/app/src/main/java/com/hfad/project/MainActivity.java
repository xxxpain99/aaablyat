package com.hfad.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.hfad.project.adapter.CategoryAdapter;
import com.hfad.project.adapter.CourseAdapter;
import com.hfad.project.model.Category;
import com.hfad.project.model.Course;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView categoryRecycler, courseRecycler;
    CategoryAdapter categoryAdapter;
    static CourseAdapter courseAdapter;
    static List<Course> courseList = new ArrayList<>();
    static List<Course> fulLCourseList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List<Category> categoryList = new ArrayList<>();
        categoryList.add(new Category(1, "Игры"));
        categoryList.add(new Category(2, "Сайты"));
        categoryList.add(new Category(3, "Языки"));
        categoryList.add(new Category(4, "Прочее"));

        setCategoryRecycler(categoryList);


        courseList.add(new Course(1, "java2", "Профессия Java \nразработчик", "10 января", "начальный", "#424345", "Программа обучения Джава – рассчитана на новичков в данной сфере. За программу вы изучите построение графических приложений под ПК, разработку веб сайтов на основе Java Spring Boot, изучите построение полноценных Андроид приложений и отлично изучите сам язык Джава!", 3));
        courseList.add(new Course(2, "python3", "Профессия Python \nразработчик", "15 января", "начальный", "#9FA520", "test", 3));
        courseList.add(new Course(3, "unity", "Профессия Unity \nразработчик", "10 января", "начальный", "#651730", "test", 1));
        courseList.add(new Course(4, "front_end", "Профессия Front-End \nразработчик", "8 января", "начальный", "#B04935", "test", 2));
        courseList.add(new Course(5, "back_end", "Профессия Back-End\nразработчик", "7 января", "начальный", "#2D55A5", "test", 2));
        courseList.add(new Course(6, "full_stack", "Профессия Full Stack \nразработчик", "5 января", "начальный", "#FFC007", "test", 2));
        fulLCourseList.addAll(courseList);
        setCourseRecycler(courseList);

    }

    public void OpenShoppingCart(View view) {
        Intent intent = new Intent(this, OrderPage.class);
        startActivity(intent);

    }

    private void setCourseRecycler(List<Course> courseList) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        courseRecycler= findViewById(R.id.courseRecycler);
        courseRecycler.setLayoutManager(layoutManager);

        courseAdapter= new CourseAdapter(this, courseList);
        courseRecycler.setAdapter(courseAdapter);
    }

    private void setCategoryRecycler(List<Category> categoryList) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        categoryRecycler= findViewById(R.id.categoryRecycler);
        categoryRecycler.setLayoutManager(layoutManager);

        categoryAdapter= new CategoryAdapter(this, categoryList);
        categoryRecycler.setAdapter(categoryAdapter);
    }

    public static void showCoursesByCategory(int category) {

        courseList.clear();
        courseList.addAll(fulLCourseList);

        List<Course> filterCourses = new ArrayList<>();

        for(Course c : courseList) {
            if(c.getCategory() == category)
                filterCourses.add(c);
        }

        courseList.clear();
        courseList.addAll(filterCourses);
        courseAdapter.notifyDataSetChanged();
    }


}